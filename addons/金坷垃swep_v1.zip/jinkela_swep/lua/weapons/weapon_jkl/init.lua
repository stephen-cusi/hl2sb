--========== Copyleft � 2010, Team Sandbox, Some rights reserved. ===========--
--
-- Purpose: Initialize the base scripted weapon.
--
--===========================================================================--

include( "shared.lua" )

function SWEP:CapabilitiesGet()
end
